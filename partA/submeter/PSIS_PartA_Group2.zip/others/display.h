#include "structs.h"

// Function to draw the display
int display (player_data_t players[8], alien_data_t aliens[N_ALIENS], pewpew_t zaps[2][16], time_t time, WINDOW * space, WINDOW * score_board);