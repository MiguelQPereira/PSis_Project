
To define the IP of the server go to the <others> folder in the <structs.h> file change the IP_ADRESS

The makefiles are in each individual folder and we implemented a <make clean> rule